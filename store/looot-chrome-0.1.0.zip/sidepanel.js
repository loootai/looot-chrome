// src/lib/api.ts
var BASE_URL = "https://api.looot.ai";
var TERMINAL = /* @__PURE__ */ new Set(["completed", "failed", "blocked", "stopped"]);
var LoootError = class extends Error {
  status;
  code;
  topUpUrl;
  constructor(status, code, message, topUpUrl) {
    super(message);
    this.name = "LoootError";
    this.status = status;
    this.code = code;
    this.topUpUrl = topUpUrl;
  }
};
function createClient(opts) {
  const doFetch = opts.fetch ?? globalThis.fetch.bind(globalThis);
  const sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
  const now = opts.now ?? (() => Date.now());
  async function request(method, path, o) {
    const url = new URL(BASE_URL + path);
    for (const [k, v] of Object.entries(o.query ?? {})) url.searchParams.set(k, String(v));
    const headers = { accept: "application/json" };
    if (o.auth) {
      const token = (await opts.getToken()).trim();
      if (!token) throw new LoootError(401, "missing_token", "Add your looot token in Settings first.");
      headers.authorization = `Bearer ${token}`;
    }
    if (o.body !== void 0) headers["content-type"] = "application/json";
    let res;
    try {
      res = await doFetch(url.toString(), {
        method,
        headers,
        body: o.body === void 0 ? void 0 : JSON.stringify(o.body),
        credentials: "omit",
        cache: "no-store"
      });
    } catch {
      throw new LoootError(0, "network", "Could not reach api.looot.ai. Check your connection and try again.");
    }
    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = null;
    }
    if (!res.ok) {
      const body = data;
      const err = body && typeof body.error === "object" ? body.error : null;
      const code = err?.code ?? (typeof body?.error === "string" ? body.error : `http_${res.status}`);
      const message = err?.message ?? body?.message ?? `looot answered HTTP ${res.status}.`;
      throw new LoootError(res.status, code, message, body?.topUpUrl);
    }
    return data;
  }
  return {
    /** Free, no token. Searches the public catalog. */
    async searchCatalog(q, limit = 20) {
      const data = await request("GET", "/v1/public-catalog", { query: { q, limit }, auth: false });
      return data?.items ?? [];
    },
    /** Free, no token. Cheapest listed price for each wanted job id. */
    async jobPrices(wanted) {
      const data = await request("GET", "/v1/catalog/overview", { query: { depth: "jobs" }, auth: false });
      const out = {};
      for (const cat of data?.categories ?? []) {
        for (const p of cat.platforms ?? []) {
          for (const j of p.jobs ?? []) {
            if (!wanted.includes(j.id) || out[j.id]) continue;
            out[j.id] = {
              id: j.id,
              title: j.title,
              providerCount: j.providerCount ?? 0,
              cheapestPerCall: j.cheapestPerCall ?? null,
              cheapestPerResult: j.cheapestPerResult ?? null
            };
          }
        }
      }
      return out;
    },
    /** Free, needs the token. */
    balance() {
      return request("GET", "/v1/balance", { auth: true });
    },
    /**
     * Paid. Runs `job:<job>` with provider fallback, capped at fallback.maxCostUsd for the whole
     * call. The same idempotency key with the same body returns the first run, so a retry never
     * pays twice. Polls until the run is terminal or timeoutMs passes.
     */
    async runJob(job, input, idempotencyKey, fallback, timeoutMs = 9e4) {
      let run = await request("POST", "/v1/runs", {
        query: { wait: 30 },
        body: { endpointId: `job:${job}`, input, idempotencyKey, fallback: { enabled: true, ...fallback } },
        auth: true
      });
      const deadline = now() + timeoutMs;
      while (!TERMINAL.has(run.status) && now() < deadline) {
        await sleep(2e3);
        run = await request("GET", `/v1/runs/${encodeURIComponent(run.runId)}`, { auth: true });
      }
      return run;
    }
  };
}

// src/lib/actions.ts
var JOB_COMPANY = "company.enrich";
var JOB_EMAIL_FIND = "people.email.find";
var JOB_EMAIL_VERIFY = "people.email.verify";
var JOB_TECH = "company.technographics";
var ALL_JOBS = [JOB_COMPANY, JOB_EMAIL_FIND, JOB_EMAIL_VERIFY, JOB_TECH];
var ACTIONS = [
  { id: "company", title: "Enrich this company", hint: "Name, industry, size, country and LinkedIn from the domain.", jobs: [JOB_COMPANY] },
  { id: "email", title: "Find work email", hint: "A person's work address at this domain, then a deliverability check.", jobs: [JOB_EMAIL_FIND, JOB_EMAIL_VERIFY] },
  { id: "tech", title: "Tech stack", hint: "The technologies this company's website uses.", jobs: [JOB_TECH] }
];
function newKey(job, uuid = () => crypto.randomUUID()) {
  return `chrome-${job}-${uuid()}`;
}

// src/lib/domain.ts
var HOST_RE = /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;
function domainFromUrl(url) {
  if (!url) return null;
  let u;
  try {
    u = new URL(url);
  } catch {
    return null;
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") return null;
  return cleanHost(u.hostname);
}
function domainFromInput(text) {
  const t = text.trim().toLowerCase();
  if (!t) return null;
  if (/^https?:\/\//.test(t)) return domainFromUrl(t);
  return cleanHost(t.split(/[/?#]/)[0] ?? "");
}
function cleanHost(host) {
  const h2 = host.toLowerCase().replace(/\.$/, "").replace(/^www\./, "");
  return HOST_RE.test(h2) ? h2 : null;
}

// src/lib/format.ts
function usd(n) {
  if (n === null || n === void 0 || !Number.isFinite(n)) return "n/a";
  if (n === 0) return "$0";
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 0.01) {
    const two = abs.toFixed(2);
    return sign + "$" + (Math.abs(Number(two) - abs) < 1e-9 ? two : abs.toFixed(4).replace(/0+$/, ""));
  }
  return sign + "$" + abs.toFixed(6).replace(/0+$/, "");
}
function itemPrice(price) {
  if (!price || price.state !== "known" || price.amountMicros === null || price.amountMicros === void 0) return "price not listed";
  const unit = price.unit === "result" ? "result" : price.unit ?? "call";
  if (price.amountMicros === 0) return `free per ${unit}`;
  return `${usd(price.amountMicros / 1e6)} per ${unit}`;
}
function jobFrom(p) {
  if (!p) return "price loading";
  if (p.cheapestPerCall !== null && p.cheapestPerCall > 0) return `from ${usd(p.cheapestPerCall)} per call`;
  if (p.cheapestPerCall === 0 && p.cheapestPerResult !== null && p.cheapestPerResult > 0) {
    return `free with one provider, others from ${usd(p.cheapestPerResult)} per result`;
  }
  if (p.cheapestPerCall === 0) return "free with the cheapest provider";
  if (p.cheapestPerResult !== null) return `from ${usd(p.cheapestPerResult)} per result`;
  return "price not listed";
}
function parseUsd(text) {
  const n = Number(text.replace(/[$\s]/g, "").replace(",", "."));
  return Number.isFinite(n) && n > 0 ? n : null;
}

// src/lib/read.ts
function squash(k) {
  return k.toLowerCase().replace(/[\s_\-.]/g, "");
}
function scalar(v) {
  if (typeof v === "string") return v.trim();
  if (typeof v === "number" && Number.isFinite(v)) return String(v);
  return "";
}
function findValue(source, keys) {
  const wanted = keys.map(squash);
  let level = [source];
  for (let depth = 0; depth < 5 && level.length > 0; depth++) {
    const next = [];
    for (const node of level) {
      if (node === null || typeof node !== "object") continue;
      if (Array.isArray(node)) {
        next.push(...node.slice(0, 5));
        continue;
      }
      const entries = Object.entries(node);
      for (const key of wanted) {
        for (const [k, v] of entries) {
          if (squash(k) !== key) continue;
          const s = scalar(v);
          if (s) return s;
        }
      }
      for (const [, v] of entries) if (v !== null && typeof v === "object") next.push(v);
    }
    level = next;
  }
  return "";
}
function pick(run, keys) {
  return findValue(run.normalized?.fields ?? null, keys) || findValue(run.result ?? null, keys);
}
var EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
function readEmail(run) {
  const direct = pick(run, ["email", "work_email", "emailAddress"]);
  if (direct && EMAIL_RE.test(direct)) return direct.match(EMAIL_RE)?.[0] ?? "";
  const m = JSON.stringify(run.result ?? "").match(EMAIL_RE);
  return m ? m[0] : "";
}
var STATUS_WORDS = {
  valid: "valid",
  deliverable: "valid",
  ok: "valid",
  safe: "valid",
  verified: "valid",
  invalid: "invalid",
  undeliverable: "invalid",
  bounce: "invalid",
  bad: "invalid",
  catchall: "catch-all",
  acceptall: "catch-all",
  risky: "risky",
  unknown: "unknown"
};
function readStatus(run) {
  const raw = pick(run, ["email_status", "verdict", "result", "status", "check", "state"]);
  return STATUS_WORDS[squash(raw)] ?? (raw ? "unknown" : "");
}
function readCompany(run) {
  const rows = [
    ["Name", ["name", "company_name", "companyName", "display_name", "legal_name"]],
    ["Industry", ["industry", "category", "sector"]],
    ["Employees", ["employees", "employee_count", "employeeCount", "size", "headcount", "estimated_num_employees"]],
    ["Founded", ["founded", "founded_year", "foundedYear", "year_founded"]],
    ["Country", ["country", "country_code", "countryCode", "hq_country"]],
    ["City", ["city", "locality", "hq_city"]],
    ["LinkedIn", ["linkedin_url", "linkedinUrl", "linkedin"]],
    ["About", ["description", "short_description", "summary", "tagline"]]
  ];
  return rows.map(([label, keys]) => ({ label, value: pick(run, keys) })).filter((f) => f.value !== "");
}
var TECH_KEY = /tech|stack|tool|framework|product/i;
var NAME_KEYS = ["name", "technology", "tech", "title", "product", "slug"];
function readTechnologies(run, max = 60) {
  const out = /* @__PURE__ */ new Set();
  const visit = (node, underTech, depth) => {
    if (out.size >= max || depth > 6 || node === null || node === void 0) return;
    if (Array.isArray(node)) {
      for (const item of node) {
        if (out.size >= max) return;
        if (typeof item === "string") {
          if (underTech && item.trim() && item.length <= 60) out.add(item.trim());
        } else if (item && typeof item === "object" && !Array.isArray(item) && underTech) {
          const rec = item;
          const key = NAME_KEYS.find((k) => typeof rec[k] === "string" && rec[k].trim() !== "");
          if (key) out.add(rec[key].trim());
          for (const [k, v] of Object.entries(rec)) if (v && typeof v === "object") visit(v, TECH_KEY.test(k), depth + 1);
        } else {
          visit(item, underTech, depth + 1);
        }
      }
      return;
    }
    if (typeof node === "object") {
      for (const [k, v] of Object.entries(node)) {
        if (v && typeof v === "object") visit(v, underTech || TECH_KEY.test(k), depth + 1);
      }
    }
  };
  visit(run.normalized?.fields ?? null, false, 0);
  visit(run.result ?? null, false, 0);
  return [...out];
}

// src/lib/spend.ts
var EMPTY_SPEND = { spent: 0, reserved: 0, runs: 0 };
var round = (n) => Math.round(n * 1e6) / 1e6;
function canSpend(s, cap, maxCost) {
  return round(s.spent + s.reserved + maxCost) <= round(cap);
}
function left(s, cap) {
  return Math.max(0, round(cap - s.spent - s.reserved));
}
function reserve(s, maxCost) {
  return { ...s, reserved: round(s.reserved + maxCost) };
}
function settle(s, maxCost, actual) {
  return {
    spent: round(s.spent + (actual === null ? maxCost : Math.max(0, actual))),
    reserved: Math.max(0, round(s.reserved - maxCost)),
    runs: s.runs + 1
  };
}

// src/lib/runner.ts
async function runStep(deps, job, input, idempotencyKey) {
  const { maxPerCall, sessionCap } = deps.limits();
  const before = deps.getSpend();
  if (!canSpend(before, sessionCap, maxPerCall)) {
    throw new LoootError(
      0,
      "session_cap",
      `This call can charge up to ${usd(maxPerCall)} and only ${usd(left(before, sessionCap))} is left under your ${usd(sessionCap)} session cap. Raise the cap or reset the counter in Settings.`
    );
  }
  await deps.setSpend(reserve(before, maxPerCall));
  let run;
  try {
    run = await deps.client.runJob(job, input, idempotencyKey, { maxAttempts: 3, maxCostUsd: maxPerCall });
  } catch (err) {
    const refused = err instanceof LoootError && err.status >= 400 && err.status < 500;
    await deps.setSpend(settle(deps.getSpend(), maxPerCall, refused ? 0 : null));
    throw err;
  }
  const settled = TERMINAL.has(run.status);
  const actual = settled ? Math.max(0, run.actualCost ?? 0) : null;
  await deps.setSpend(settle(deps.getSpend(), maxPerCall, actual));
  return { run, counted: actual ?? maxPerCall, settled };
}

// src/lib/store.ts
var DEFAULTS = { token: "", maxPerCall: 0.05, sessionCap: 0.5 };
var num = (v, fallback) => typeof v === "number" && Number.isFinite(v) && v > 0 ? v : fallback;
async function loadSettings(local2) {
  const raw = await local2.get(["token", "maxPerCall", "sessionCap"]);
  return {
    token: typeof raw.token === "string" ? raw.token : "",
    maxPerCall: num(raw.maxPerCall, DEFAULTS.maxPerCall),
    sessionCap: num(raw.sessionCap, DEFAULTS.sessionCap)
  };
}
async function saveToken(local2, token) {
  const t = token.trim();
  if (t) await local2.set({ token: t });
  else await local2.remove(["token"]);
}
function saveLimits(local2, maxPerCall, sessionCap) {
  return local2.set({ maxPerCall, sessionCap });
}
async function loadSpend(session2) {
  const raw = (await session2.get(["spend"])).spend;
  if (!raw) return { ...EMPTY_SPEND };
  return { spent: Math.round((num(raw.spent, 0) + num(raw.reserved, 0)) * 1e6) / 1e6, reserved: 0, runs: num(raw.runs, 0) };
}
function saveSpend(session2, spend) {
  return session2.set({ spend });
}

// src/panel/dom.ts
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === void 0 || v === false) continue;
    if (k.startsWith("on") && typeof v === "function") {
      el.addEventListener(k.slice(2).toLowerCase(), v);
    } else if (k === "class") {
      el.className = String(v);
    } else if (k === "value" && "value" in el) {
      el.value = String(v);
    } else {
      el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  for (const c of children) if (c !== null && c !== void 0 && c !== false) el.append(c);
  return el;
}
function mount(target, ...children) {
  target.replaceChildren(...children.filter((c) => c !== null && c !== void 0 && c !== false));
}
var SVG_NS = "http://www.w3.org/2000/svg";
function icon(d) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", "0 0 16 16");
  svg.setAttribute("width", "16");
  svg.setAttribute("height", "16");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "1.5");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS(SVG_NS, "path");
  path.setAttribute("d", d);
  svg.append(path);
  return svg;
}
var ICONS = {
  search: "M7 12.5a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11ZM14.5 14.5 11 11",
  globe: "M8 14.5a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM1.5 8h13M8 1.5c2 2.2 2 10.8 0 13M8 1.5c-2 2.2-2 10.8 0 13",
  building: "M3 14.5v-12h7v12M10 6.5h3v8M1.5 14.5h13M5.5 5.5h2M5.5 8.5h2M5.5 11.5h2",
  mail: "M1.5 4h13v8.5h-13zM1.5 4.5 8 9l6.5-4.5",
  layers: "M8 1.5 1.5 5 8 8.5 14.5 5 8 1.5ZM1.5 8 8 11.5 14.5 8M1.5 11 8 14.5 14.5 11",
  check: "M3 8.5 6.5 12 13 4.5",
  copy: "M6 6h7.5v7.5H6zM10 3.5V2.5H2.5V10h1",
  alert: "M8 5.5v3.5M8 11.5v.01M8 1.5l6.5 12h-13L8 1.5Z",
  lock: "M4 7.5h8v6H4zM5.5 7.5v-2a2.5 2.5 0 0 1 5 0v2",
  edit: "M2.5 13.5h3l7.5-7.5-3-3-7.5 7.5v3ZM9 4l3 3"
};

// src/panel/main.ts
var local = chrome.storage.local;
var session = chrome.storage.session;
var state = {
  settings: { ...DEFAULTS },
  spend: { ...EMPTY_SPEND },
  prices: null,
  pricesError: false,
  tabDomain: null,
  manualDomain: null,
  editingDomain: false,
  balance: null,
  phases: { company: { kind: "idle" }, email: { kind: "idle" }, tech: { kind: "idle" } },
  person: { first: "", last: "" },
  catalog: { q: "", status: "idle", items: [], seq: 0 },
  settingsNote: ""
};
var client = createClient({ getToken: async () => state.settings.token });
var $ = (id) => document.getElementById(id);
var domain = () => state.manualDomain ?? state.tabDomain;
var ACTION_ICONS = { company: ICONS.building, email: ICONS.mail, tech: ICONS.layers };
function renderSite() {
  const d = domain();
  if (state.editingDomain || !d) {
    const input = h("input", {
      id: "domain-input",
      type: "text",
      inputmode: "url",
      autocomplete: "off",
      spellcheck: "false",
      placeholder: "company.com",
      value: d ?? "",
      "aria-describedby": "domain-help"
    });
    const error = h("p", { class: "field-error", role: "alert", hidden: true }, "Type a domain such as company.com.");
    const submit = (e) => {
      e.preventDefault();
      const next = domainFromInput(input.value);
      if (!next) {
        error.hidden = false;
        input.setAttribute("aria-invalid", "true");
        return;
      }
      state.manualDomain = next;
      state.editingDomain = false;
      resetPhases();
      renderSite();
      renderLookup();
    };
    mount(
      $("site"),
      h(
        "form",
        { class: "site-form", onsubmit: submit },
        h("label", { for: "domain-input" }, "Company domain"),
        h("div", { class: "row" }, input, h("button", { class: "btn", type: "submit" }, "Use")),
        error,
        h(
          "p",
          { id: "domain-help", class: "help" },
          d ? "Lookups will use this domain instead of the open tab." : "This tab has no site to use. Click the looot icon on a company's website, or type a domain."
        )
      )
    );
    if (state.editingDomain) input.focus();
    return;
  }
  mount(
    $("site"),
    h(
      "div",
      { class: "site-chip" },
      h("span", { class: "site-icon" }, icon(ICONS.globe)),
      h(
        "div",
        { class: "site-text" },
        h("span", { class: "eyebrow" }, state.manualDomain ? "Typed domain" : "This tab"),
        h("span", { class: "domain", title: d }, d)
      ),
      h("button", {
        class: "btn ghost small",
        type: "button",
        "aria-label": "Change domain",
        onclick: () => {
          state.editingDomain = true;
          renderSite();
        }
      }, icon(ICONS.edit), "Change")
    )
  );
}
async function readTab() {
  let next = null;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    next = domainFromUrl(tab?.url);
  } catch {
    next = null;
  }
  if (next === state.tabDomain) return;
  const changed = next !== domain();
  state.tabDomain = next;
  state.manualDomain = null;
  state.editingDomain = false;
  if (changed) resetPhases();
  renderSite();
  renderLookup();
}
function resetPhases() {
  for (const a of ACTIONS) if (state.phases[a.id].kind !== "running") state.phases[a.id] = { kind: "idle" };
}
function renderLookup() {
  const view = $("view-lookup");
  const children = [];
  if (!state.settings.token) {
    children.push(
      h(
        "div",
        { class: "notice" },
        h("span", { class: "notice-icon" }, icon(ICONS.lock)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, "Lookups need your looot token"),
          h("p", { class: "help" }, "Catalog search is free and works now. To run a lookup, paste a token from your looot account. It stays on this device."),
          h(
            "div",
            { class: "row" },
            h("button", { class: "btn", type: "button", onclick: () => selectTab("settings") }, "Add token"),
            h("a", { class: "btn ghost", href: "https://looot.ai/settings", target: "_blank", rel: "noopener" }, "Get one at looot.ai")
          )
        )
      )
    );
  }
  if (state.pricesError) {
    children.push(
      h(
        "div",
        { class: "notice warn", role: "alert" },
        h("span", { class: "notice-icon" }, icon(ICONS.alert)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, "Prices did not load"),
          h("p", { class: "help" }, "Lookups stay off until the price list is back, so you always see the price first."),
          h("button", { class: "btn ghost", type: "button", onclick: () => void loadPrices(true) }, "Try again")
        )
      )
    );
  }
  children.push(h("ul", { class: "actions" }, ...ACTIONS.map(renderAction)));
  mount(view, ...children);
}
function priceLine(job) {
  if (!state.prices) return h("span", { class: state.pricesError ? "price muted" : "price skeleton" }, state.pricesError ? "price unavailable" : "from $0.0000 per call");
  return h("span", { class: "price" }, jobFrom(state.prices[job]));
}
function renderAction(action) {
  const phase = state.phases[action.id];
  const d = domain();
  const ready = Boolean(state.settings.token && state.prices && d);
  const head = h(
    "div",
    { class: "action-head" },
    h("span", { class: "action-icon" }, icon(ACTION_ICONS[action.id])),
    h(
      "div",
      { class: "action-text" },
      h("h2", {}, action.title),
      h("p", { class: "help" }, action.hint),
      h("p", { class: "price-row" }, priceLine(action.jobs[0]))
    )
  );
  const body = [];
  if (phase.kind === "idle") {
    if (action.id === "email") {
      const first = h("input", { id: "first-name", type: "text", autocomplete: "off", value: state.person.first, oninput: (e) => {
        state.person.first = e.target.value;
      } });
      const last = h("input", { id: "last-name", type: "text", autocomplete: "off", value: state.person.last, oninput: (e) => {
        state.person.last = e.target.value;
      } });
      const error = h("p", { class: "field-error", role: "alert", hidden: true }, "Enter a first and a last name.");
      body.push(
        h(
          "form",
          {
            class: "stack",
            onsubmit: (e) => {
              e.preventDefault();
              const f = state.person.first.trim();
              const l = state.person.last.trim();
              if (!f || !l) {
                error.hidden = false;
                return;
              }
              startConfirm(action, { first: f, last: l });
            }
          },
          h(
            "div",
            { class: "grid2" },
            h("div", { class: "field" }, h("label", { for: "first-name" }, "First name"), first),
            h("div", { class: "field" }, h("label", { for: "last-name" }, "Last name"), last)
          ),
          error,
          h("button", { class: "btn", type: "submit", disabled: !ready }, "See price")
        )
      );
    } else {
      body.push(h("button", { class: "btn", type: "button", disabled: !ready, onclick: () => startConfirm(action, {}) }, "See price"));
    }
    if (!d) body.push(h("p", { class: "help" }, "Needs a company domain."));
  }
  if (phase.kind === "confirm") {
    const cap = state.settings.maxPerCall;
    const jobs = action.jobs;
    const most = cap * jobs.length;
    body.push(
      h(
        "div",
        { class: "confirm", role: "group", "aria-label": `Confirm ${action.title}` },
        h(
          "p",
          { class: "confirm-target" },
          action.id === "email" ? `${phase.first} ${phase.last} at ` : "On ",
          h("span", { class: "domain" }, phase.domain)
        ),
        h(
          "ul",
          { class: "steps" },
          ...jobs.map(
            (job, i) => h(
              "li",
              {},
              h("span", { class: "mono job" }, `job:${job}`),
              h("span", { class: "price" }, jobFrom(state.prices?.[job])),
              i > 0 ? h("span", { class: "help" }, "Runs only if an address is found.") : null
            )
          )
        ),
        h(
          "p",
          { class: "cap-line" },
          "Most this can charge: ",
          h("strong", { class: "mono" }, usd(most)),
          jobs.length > 1 ? ` (${usd(cap)} cap per call)` : " (your cap per call)",
          ". A failed call costs $0."
        ),
        h(
          "div",
          { class: "row" },
          h("button", { class: "btn primary", type: "button", onclick: () => void runAction(action, phase) }, `Confirm and run`),
          h("button", { class: "btn ghost", type: "button", onclick: () => setPhase(action.id, { kind: "idle" }) }, "Cancel")
        )
      )
    );
  }
  if (phase.kind === "running") {
    body.push(
      h(
        "div",
        { class: "running", role: "status" },
        h("span", { class: "spinner", "aria-hidden": "true" }),
        h("span", {}, phase.label)
      ),
      h("div", { class: "skeleton-block", "aria-hidden": "true" }, h("span", {}), h("span", {}), h("span", {}))
    );
  }
  if (phase.kind === "done") {
    const total = phase.steps.reduce((sum, s) => sum + s.counted, 0);
    const raw = JSON.stringify(phase.steps.map((s) => ({ runId: s.run.runId, status: s.run.status, actualCost: s.run.actualCost, result: s.run.result })), null, 2);
    const copy = h("button", { class: "btn ghost small", type: "button", onclick: () => void copyText(raw, copy) }, icon(ICONS.copy), "Copy JSON");
    body.push(
      h(
        "div",
        { class: "result" },
        phase.headline ? h("p", { class: "headline" }, phase.headline) : null,
        phase.note ? h("p", { class: "help" }, phase.note) : null,
        phase.fields.length > 0 ? h("dl", { class: "fields" }, ...phase.fields.flatMap((f) => [h("dt", {}, f.label), h("dd", { title: f.value }, f.value)])) : null,
        phase.chips.length > 0 ? h("ul", { class: "chips" }, ...phase.chips.map((c) => h("li", {}, c))) : null,
        h(
          "div",
          { class: "receipt" },
          h("span", { class: "receipt-label" }, "Charged"),
          h("strong", { class: "mono" }, usd(total)),
          h("span", { class: "help" }, phase.steps.map((s) => s.run.route?.servedBy).filter(Boolean).join(", "))
        ),
        ...phase.steps.filter((s) => !s.settled).map(
          () => h("p", { class: "help" }, "A run was still going when the panel stopped waiting. The full cap was counted. Check the run on looot.ai.")
        ),
        h("details", {}, h("summary", {}, "Raw answer"), h("pre", {}, raw.length > 6e3 ? raw.slice(0, 6e3) + "\n..." : raw)),
        h(
          "div",
          { class: "row" },
          copy,
          h("button", { class: "btn ghost small", type: "button", onclick: () => setPhase(action.id, { kind: "idle" }) }, "Run another")
        )
      )
    );
  }
  if (phase.kind === "error") {
    body.push(
      h(
        "div",
        { class: "notice warn", role: "alert" },
        h("span", { class: "notice-icon" }, icon(ICONS.alert)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, "Nothing ran"),
          h("p", { class: "help" }, phase.message),
          h(
            "div",
            { class: "row" },
            phase.retry ? h("button", { class: "btn", type: "button", onclick: () => setPhase(action.id, phase.retry) }, "Back") : null,
            phase.topUpUrl ? h("a", { class: "btn ghost", href: phase.topUpUrl, target: "_blank", rel: "noopener" }, "Top up") : null,
            h("button", { class: "btn ghost", type: "button", onclick: () => setPhase(action.id, { kind: "idle" }) }, "Dismiss")
          )
        )
      )
    );
  }
  return h("li", { class: `action is-${phase.kind}`, id: `action-${action.id}` }, head, ...body);
}
function setPhase(id, phase) {
  state.phases[id] = phase;
  renderLookup();
}
function startConfirm(action, person) {
  const d = domain();
  if (!d) return;
  const keys = {};
  for (const job of action.jobs) keys[job] = newKey(job);
  setPhase(action.id, { kind: "confirm", domain: d, keys, ...person });
}
function safeUrl(u) {
  return u && /^https:\/\/([a-z0-9-]+\.)*looot\.ai(\/|$)/.test(u) ? u : void 0;
}
function describeFailure(run) {
  return run.error?.message ?? `The run ended as ${run.status}.`;
}
async function runAction(action, phase) {
  const deps = {
    client,
    limits: () => ({ maxPerCall: state.settings.maxPerCall, sessionCap: state.settings.sessionCap }),
    getSpend: () => state.spend,
    setSpend: async (s) => {
      state.spend = s;
      renderMeter();
      await saveSpend(session, s);
    }
  };
  const steps = [];
  const done = (fields, chips, headline, note) => setPhase(action.id, { kind: "done", domain: phase.domain, steps, fields, chips, headline, note });
  try {
    if (action.id === "company") {
      setPhase(action.id, { kind: "running", label: `Enriching ${phase.domain}` });
      const step = await runStep(deps, JOB_COMPANY, { domain: phase.domain }, phase.keys[JOB_COMPANY]);
      steps.push(step);
      const fields = step.run.status === "completed" ? readCompany(step.run) : [];
      const name = fields.find((f) => f.label === "Name")?.value ?? "";
      done(
        fields.filter((f) => f.label !== "Name"),
        [],
        name,
        step.run.status !== "completed" ? describeFailure(step.run) : fields.length === 0 ? "The provider answered but had no company details for this domain." : ""
      );
    } else if (action.id === "tech") {
      setPhase(action.id, { kind: "running", label: `Reading the stack of ${phase.domain}` });
      const step = await runStep(deps, JOB_TECH, { domain: phase.domain }, phase.keys[JOB_TECH]);
      steps.push(step);
      const names = step.run.status === "completed" ? readTechnologies(step.run) : [];
      done(
        [],
        names,
        names.length > 0 ? `${names.length} technologies` : "",
        step.run.status !== "completed" ? describeFailure(step.run) : names.length === 0 ? "No technology names in the answer. Open the raw answer below." : ""
      );
    } else {
      setPhase(action.id, { kind: "running", label: "Looking for the address" });
      const find = await runStep(deps, JOB_EMAIL_FIND, { first_name: phase.first ?? "", last_name: phase.last ?? "", domain: phase.domain }, phase.keys[JOB_EMAIL_FIND]);
      steps.push(find);
      const email = find.run.status === "completed" ? readEmail(find.run) : "";
      if (!email) {
        done([], [], "", find.run.status !== "completed" ? describeFailure(find.run) : "No address found for this name at this domain. The check did not run.");
        return;
      }
      setPhase(action.id, { kind: "running", label: `Checking ${email}` });
      let status = "";
      let note = "";
      try {
        const verify = await runStep(deps, JOB_EMAIL_VERIFY, { email }, phase.keys[JOB_EMAIL_VERIFY]);
        steps.push(verify);
        status = verify.run.status === "completed" ? readStatus(verify.run) : "";
        if (verify.run.status !== "completed") note = `The check did not finish: ${describeFailure(verify.run)}`;
      } catch (err) {
        note = `The address was found. The check did not run: ${err instanceof Error ? err.message : "unknown error"}`;
      }
      const fields = status ? [{ label: "Check", value: status }] : [];
      done(fields, [], email, note);
    }
  } catch (err) {
    const e = err instanceof LoootError ? err : new LoootError(0, "unknown", "Something went wrong before the call was made.");
    const message = e.status === 401 ? "looot did not accept the token. Check it in Settings." : e.status === 402 || e.code.includes("insufficient") ? `${e.message} Top up your balance and try again.` : e.message;
    if (steps.length > 0) {
      done([], [], "", message);
    } else {
      setPhase(action.id, { kind: "error", message, topUpUrl: safeUrl(e.topUpUrl), retry: e.code === "session_cap" ? void 0 : phase });
    }
  } finally {
    void loadBalance();
  }
}
async function copyText(text, button) {
  try {
    await navigator.clipboard.writeText(text);
    button.classList.add("copied");
    setTimeout(() => button.classList.remove("copied"), 1200);
  } catch {
  }
}
var SUGGESTIONS = ["find work email", "company enrichment", "google search", "linkedin profile", "verify email", "tech stack"];
function renderCatalog() {
  const view = $("view-catalog");
  const input = h("input", {
    id: "catalog-q",
    type: "search",
    placeholder: "What do you need? e.g. verify an email",
    autocomplete: "off",
    value: state.catalog.q,
    "aria-label": "Search the looot catalog",
    oninput: (e) => queueSearch(e.target.value)
  });
  mount(
    view,
    h("div", { class: "search" }, h("span", { class: "search-icon" }, icon(ICONS.search)), input),
    h("p", { class: "help" }, "Free. No token needed. Prices are what one call or one result costs through looot."),
    h("div", { id: "catalog-results", "aria-live": "polite" })
  );
  renderCatalogResults();
}
function renderCatalogResults() {
  const box = document.getElementById("catalog-results");
  if (!box) return;
  const c = state.catalog;
  if (c.status === "idle") {
    mount(
      box,
      h(
        "div",
        { class: "empty" },
        h("p", { class: "empty-title" }, "Search 2,500+ endpoints from 90+ providers"),
        h("p", { class: "help" }, "Describe the task. Start with one of these:"),
        h("ul", { class: "chips click" }, ...SUGGESTIONS.map((s) => h("li", {}, h("button", { type: "button", onclick: () => {
          state.catalog.q = s;
          renderCatalog();
          void search(s);
        } }, s))))
      )
    );
  } else if (c.status === "loading") {
    mount(box, h("ul", { class: "results", "aria-busy": "true" }, ...[0, 1, 2, 3].map(() => h("li", { class: "result-row skeleton-row", "aria-hidden": "true" }, h("span", {}), h("span", {}), h("span", {})))));
  } else if (c.status === "error") {
    mount(
      box,
      h(
        "div",
        { class: "notice warn", role: "alert" },
        h("span", { class: "notice-icon" }, icon(ICONS.alert)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, "Search did not answer"),
          h("p", { class: "help" }, "api.looot.ai could not be reached. Check your connection."),
          h("button", { class: "btn ghost", type: "button", onclick: () => void search(c.q) }, "Try again")
        )
      )
    );
  } else if (c.items.length === 0) {
    mount(
      box,
      h(
        "div",
        { class: "empty" },
        h("p", { class: "empty-title" }, `Nothing matched "${c.q}"`),
        h("p", { class: "help" }, 'Use fewer words, or name the task instead of a vendor: "verify email", "company news".')
      )
    );
  } else {
    mount(box, h("ul", { class: "results" }, ...c.items.map(renderItem)));
  }
}
function plain(text) {
  return text.replace(/\*\*|`/g, "").replace(/\s+/g, " ").trim();
}
function renderItem(item) {
  const slash = item.title.indexOf(" / ");
  const provider = slash > 0 ? item.title.slice(0, slash) : item.providerId;
  const title = slash > 0 ? item.title.slice(slash + 3) : item.title;
  const copy = h("button", { class: "btn ghost small", type: "button", title: "Copy the operation id", onclick: () => void copyText(item.operationId, copy) }, icon(ICONS.copy), "Copy id");
  return h(
    "li",
    { class: "result-row" },
    h(
      "div",
      { class: "result-top" },
      h("span", { class: "eyebrow" }, provider),
      h("span", { class: "price" }, itemPrice(item.price))
    ),
    h("h3", {}, title),
    item.description ? h("p", { class: "help clamp" }, plain(item.description)) : null,
    h("div", { class: "result-foot" }, h("code", { class: "mono id", title: item.operationId }, item.operationId), copy)
  );
}
var searchTimer;
function queueSearch(q) {
  state.catalog.q = q;
  clearTimeout(searchTimer);
  if (!q.trim()) {
    state.catalog.status = "idle";
    state.catalog.seq++;
    renderCatalogResults();
    return;
  }
  searchTimer = setTimeout(() => void search(q), 300);
}
async function search(q) {
  const text = q.trim().slice(0, 200);
  if (!text) return;
  const seq = ++state.catalog.seq;
  state.catalog.status = "loading";
  renderCatalogResults();
  try {
    const items = await client.searchCatalog(text, 20);
    if (seq !== state.catalog.seq) return;
    state.catalog.items = items;
    state.catalog.status = "done";
  } catch {
    if (seq !== state.catalog.seq) return;
    state.catalog.status = "error";
  }
  renderCatalogResults();
}
function renderSettings() {
  const view = $("view-settings");
  const hasToken = Boolean(state.settings.token);
  const token = h("input", { id: "token", type: "password", autocomplete: "off", spellcheck: "false", placeholder: hasToken ? "A token is saved. Paste a new one to replace it." : "cs_ms_..." });
  const tokenNote = h("p", { class: "help", role: "status" }, state.settingsNote);
  const perCall = h("input", { id: "max-per-call", type: "text", inputmode: "decimal", value: String(state.settings.maxPerCall) });
  const cap = h("input", { id: "session-cap", type: "text", inputmode: "decimal", value: String(state.settings.sessionCap) });
  const limitsError = h("p", { class: "field-error", role: "alert", hidden: true }, "Enter two amounts above 0. The session cap must be at least the cap per call.");
  const limitsNote = h("p", { class: "help", role: "status" });
  mount(
    view,
    h(
      "form",
      {
        class: "stack card",
        onsubmit: (e) => {
          e.preventDefault();
          const value = token.value.trim();
          if (!value) return;
          void (async () => {
            await saveToken(local, value);
            state.settings.token = value;
            state.settingsNote = "Saved on this device.";
            try {
              const b = await client.balance();
              state.balance = typeof b?.available === "number" ? b.available : null;
            } catch (err) {
              state.balance = null;
              if (err instanceof LoootError && err.status === 401) state.settingsNote = "Saved, but looot did not accept this token. Check that you copied all of it.";
            }
            renderAll();
          })();
        }
      },
      h("h2", {}, "Your looot token"),
      h(
        "div",
        { class: "field" },
        h("label", { for: "token" }, "Agent token"),
        token,
        h("p", { class: "help" }, "Kept in this browser's local extension storage. Not synced to your Google account. Sent only to api.looot.ai.")
      ),
      tokenNote,
      h(
        "div",
        { class: "row" },
        h("button", { class: "btn primary", type: "submit" }, hasToken ? "Replace token" : "Save token"),
        hasToken ? h("button", {
          class: "btn ghost",
          type: "button",
          onclick: () => void (async () => {
            await saveToken(local, "");
            state.settings.token = "";
            state.balance = null;
            state.settingsNote = "Token removed.";
            renderAll();
          })()
        }, "Remove") : null
      ),
      h(
        "p",
        { class: "help" },
        "No token yet? Create one in your ",
        h("a", { href: "https://looot.ai/settings", target: "_blank", rel: "noopener" }, "looot account"),
        " with catalog.read, runs.read and runs.execute. Top up from $5, no subscription."
      )
    ),
    h(
      "form",
      {
        class: "stack card",
        onsubmit: (e) => {
          e.preventDefault();
          const a = parseUsd(perCall.value);
          const b = parseUsd(cap.value);
          if (a === null || b === null || b < a) {
            limitsError.hidden = false;
            return;
          }
          limitsError.hidden = true;
          state.settings.maxPerCall = a;
          state.settings.sessionCap = b;
          void saveLimits(local, a, b).then(() => {
            limitsNote.textContent = "Limits saved.";
            renderMeter();
            renderLookup();
          });
        }
      },
      h("h2", {}, "Spending limits"),
      h(
        "div",
        { class: "grid2" },
        h("div", { class: "field" }, h("label", { for: "max-per-call" }, "Cap per call (USD)"), perCall),
        h("div", { class: "field" }, h("label", { for: "session-cap" }, "Session cap (USD)"), cap)
      ),
      limitsError,
      h("p", { class: "help" }, "A call never charges more than its cap, across every provider looot tries. When the session total could pass the session cap, lookups stop."),
      limitsNote,
      h(
        "div",
        { class: "row" },
        h("button", { class: "btn", type: "submit" }, "Save limits"),
        h("button", {
          class: "btn ghost",
          type: "button",
          onclick: () => {
            state.spend = { ...EMPTY_SPEND };
            void saveSpend(session, state.spend);
            renderMeter();
            limitsNote.textContent = "Session counter reset.";
          }
        }, "Reset session counter")
      )
    ),
    h(
      "div",
      { class: "card links" },
      h("h2", {}, "About"),
      h("p", { class: "help" }, "This panel talks to api.looot.ai and nothing else. No analytics, no tracking, no page content is read."),
      h(
        "p",
        { class: "link-row" },
        h("a", { href: "https://looot.ai", target: "_blank", rel: "noopener" }, "looot.ai"),
        h("a", { href: "https://docs.looot.ai", target: "_blank", rel: "noopener" }, "Docs"),
        h("a", { href: "https://looot.ai/privacy", target: "_blank", rel: "noopener" }, "Privacy"),
        h("a", { href: "https://looot.ai/contact", target: "_blank", rel: "noopener" }, "Support"),
        h("a", { href: "https://github.com/loootai/looot-chrome", target: "_blank", rel: "noopener" }, "Source")
      )
    )
  );
}
function renderMeter() {
  const { spend, settings } = state;
  const used = spend.spent + spend.reserved;
  const pct = Math.min(100, Math.round(used / settings.sessionCap * 100));
  mount(
    $("meter"),
    h(
      "div",
      { class: "meter-row" },
      h("span", {}, "Session ", h("strong", { class: "mono" }, usd(spend.spent)), ` of ${usd(settings.sessionCap)}`),
      h("span", { class: "help" }, spend.reserved > 0 ? `${usd(spend.reserved)} held` : `${usd(left(spend, settings.sessionCap))} left, ${spend.runs} ${spend.runs === 1 ? "run" : "runs"}`)
    ),
    h(
      "div",
      { class: `bar${pct >= 90 ? " full" : ""}`, role: "progressbar", "aria-label": "Session spend", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": pct },
      h("span", { style: `transform: scaleX(${pct / 100})` })
    )
  );
}
function renderBalance() {
  const el = $("balance");
  if (state.balance === null || !state.settings.token) {
    el.hidden = true;
    return;
  }
  el.hidden = false;
  mount(el, h("span", { class: "eyebrow" }, "Balance"), h("strong", { class: "mono" }, usd(Math.round(state.balance * 100) / 100)));
}
async function loadBalance() {
  if (!state.settings.token) return;
  try {
    const b = await client.balance();
    state.balance = typeof b?.available === "number" ? b.available : null;
  } catch {
    state.balance = null;
  }
  renderBalance();
}
async function loadPrices(force = false) {
  state.pricesError = false;
  if (force) {
    state.prices = null;
    renderLookup();
  }
  try {
    const cached = (await session.get(["prices"])).prices;
    if (!force && cached && Date.now() - cached.at < 30 * 6e4) {
      state.prices = cached.jobs;
    } else {
      state.prices = await client.jobPrices(ALL_JOBS);
      await session.set({ prices: { at: Date.now(), jobs: state.prices } });
    }
  } catch {
    state.prices = null;
    state.pricesError = true;
  }
  renderLookup();
}
function selectTab(name) {
  for (const tab of document.querySelectorAll('[role="tab"]')) {
    const on = tab.dataset.tab === name;
    tab.setAttribute("aria-selected", String(on));
    tab.tabIndex = on ? 0 : -1;
    $(`view-${tab.dataset.tab}`).hidden = !on;
  }
  if (name === "settings") {
    state.settingsNote = "";
    renderSettings();
  }
}
function renderAll() {
  renderSite();
  renderLookup();
  renderSettings();
  renderMeter();
  renderBalance();
}
async function init() {
  const tabs = [...document.querySelectorAll('[role="tab"]')];
  tabs.forEach((tab, i) => {
    tab.addEventListener("click", () => selectTab(tab.dataset.tab ?? "lookup"));
    tab.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const next = tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
      next.focus();
      selectTab(next.dataset.tab ?? "lookup");
    });
  });
  state.settings = await loadSettings(local);
  state.spend = await loadSpend(session);
  renderAll();
  renderCatalog();
  await readTab();
  chrome.tabs.onActivated.addListener(() => void readTab());
  chrome.tabs.onUpdated.addListener((_id, info) => {
    if (info.url || info.status === "complete") void readTab();
  });
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "looot:tab-granted") void readTab();
  });
  void loadPrices();
  void loadBalance();
}
void init();
