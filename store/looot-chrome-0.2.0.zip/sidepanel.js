// src/lib/api.ts
var BASE_URL = "https://api.looot.ai";
var TERMINAL = /* @__PURE__ */ new Set(["completed", "failed", "blocked", "stopped"]);
var LoootError = class extends Error {
  status;
  code;
  topUpUrl;
  constructor(status, code, message, topUpUrl) {
    super(message);
    this.name = "LoootError";
    this.status = status;
    this.code = code;
    this.topUpUrl = topUpUrl;
  }
};
function createClient(opts) {
  const doFetch = opts.fetch ?? globalThis.fetch.bind(globalThis);
  const sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
  const now = opts.now ?? (() => Date.now());
  async function request(method, path, o) {
    const url = new URL(BASE_URL + path);
    for (const [k, v] of Object.entries(o.query ?? {})) url.searchParams.set(k, String(v));
    const headers = { accept: "application/json" };
    if (o.auth) {
      const token = (await opts.getToken()).trim();
      if (!token) throw new LoootError(401, "missing_token", "Add your looot token in Settings first.");
      headers.authorization = `Bearer ${token}`;
    }
    if (o.body !== void 0) headers["content-type"] = "application/json";
    let res;
    try {
      res = await doFetch(url.toString(), {
        method,
        headers,
        body: o.body === void 0 ? void 0 : JSON.stringify(o.body),
        credentials: "omit",
        cache: "no-store"
      });
    } catch {
      throw new LoootError(0, "network", "Could not reach api.looot.ai. Check your connection and try again.");
    }
    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = null;
    }
    if (!res.ok) {
      const body = data;
      const err = body && typeof body.error === "object" ? body.error : null;
      const code = err?.code ?? (typeof body?.error === "string" ? body.error : `http_${res.status}`);
      const message = err?.message ?? body?.message ?? `looot answered HTTP ${res.status}.`;
      throw new LoootError(res.status, code, message, body?.topUpUrl);
    }
    return data;
  }
  return {
    /** Free, no token. Searches the public catalog. */
    async searchCatalog(q, limit = 20) {
      const data = await request("GET", "/v1/public-catalog", { query: { q, limit }, auth: false });
      return data?.items ?? [];
    },
    /** Free, no token. Cheapest listed price for each wanted job id. */
    async jobPrices(wanted) {
      const data = await request("GET", "/v1/catalog/overview", { query: { depth: "jobs" }, auth: false });
      const out = {};
      for (const cat of data?.categories ?? []) {
        for (const p of cat.platforms ?? []) {
          for (const j of p.jobs ?? []) {
            if (!wanted.includes(j.id) || out[j.id]) continue;
            out[j.id] = {
              id: j.id,
              title: j.title,
              providerCount: j.providerCount ?? 0,
              cheapestPerCall: j.cheapestPerCall ?? null,
              cheapestPerResult: j.cheapestPerResult ?? null
            };
          }
        }
      }
      return out;
    },
    /** Free, needs the token. */
    balance() {
      return request("GET", "/v1/balance", { auth: true });
    },
    /**
     * Paid. Runs `job:<job>` with provider fallback, capped at fallback.maxCostUsd for the whole
     * call. The same idempotency key with the same body returns the first run, so a retry never
     * pays twice. Polls until the run is terminal or timeoutMs passes.
     */
    async runJob(job, input, idempotencyKey, fallback, timeoutMs = 9e4) {
      let run = await request("POST", "/v1/runs", {
        query: { wait: 30 },
        body: { endpointId: `job:${job}`, input, idempotencyKey, fallback: { enabled: true, ...fallback } },
        auth: true
      });
      const deadline = now() + timeoutMs;
      while (!TERMINAL.has(run.status) && now() < deadline) {
        await sleep(2e3);
        run = await request("GET", `/v1/runs/${encodeURIComponent(run.runId)}`, { auth: true });
      }
      return run;
    }
  };
}

// src/lib/actions.ts
var JOB_COMPANY = "company.enrich";
var JOB_WHOIS = "domain.whois.lookup";
var JOB_TECH = "company.technographics";
var JOB_TRAFFIC = "company.traffic";
var JOB_SEO = "backlinks.domain.summary";
var JOB_EMAIL_FIND = "people.email.find";
var JOB_EMAIL_VERIFY = "people.email.verify";
var ACTIONS = [
  { id: "company", key: "actionCompany", jobs: [JOB_COMPANY] },
  { id: "whois", key: "actionWhois", jobs: [JOB_WHOIS] },
  { id: "tech", key: "actionTech", jobs: [JOB_TECH] },
  { id: "traffic", key: "actionTraffic", jobs: [JOB_TRAFFIC] },
  { id: "seo", key: "actionSeo", jobs: [JOB_SEO] },
  { id: "email", key: "actionEmail", jobs: [JOB_EMAIL_FIND, JOB_EMAIL_VERIFY] }
];
var ALL_JOBS = [...new Set(ACTIONS.flatMap((a) => a.jobs))];
function newKey(job, uuid = () => crypto.randomUUID()) {
  return `chrome-${job}-${uuid()}`;
}

// src/lib/domain.ts
var HOST_RE = /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;
function domainFromUrl(url) {
  if (!url) return null;
  let u;
  try {
    u = new URL(url);
  } catch {
    return null;
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") return null;
  return cleanHost(u.hostname);
}
function domainFromInput(text) {
  const t2 = text.trim().toLowerCase();
  if (!t2) return null;
  if (/^https?:\/\//.test(t2)) return domainFromUrl(t2);
  return cleanHost(t2.split(/[/?#]/)[0] ?? "");
}
function cleanHost(host) {
  const h2 = host.toLowerCase().replace(/\.$/, "").replace(/^www\./, "");
  return HOST_RE.test(h2) ? h2 : null;
}

// src/lib/i18n.ts
var getter = (key, subs) => {
  try {
    return chrome.i18n.getMessage(key, subs);
  } catch {
    return "";
  }
};
function t(key, ...subs) {
  const s = subs.map(String);
  return getter(key, s.length > 0 ? s : void 0) || key;
}
function uiLang() {
  try {
    return chrome.i18n.getUILanguage();
  } catch {
    return void 0;
  }
}

// src/lib/format.ts
function usd(n) {
  if (n === null || n === void 0 || !Number.isFinite(n)) return "n/a";
  if (n === 0) return "$0";
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 0.01) {
    const two = abs.toFixed(2);
    return sign + "$" + (Math.abs(Number(two) - abs) < 1e-9 ? two : abs.toFixed(4).replace(/0+$/, ""));
  }
  return sign + "$" + abs.toFixed(6).replace(/0+$/, "");
}
function itemPrice(price) {
  if (!price || price.state !== "known" || price.amountMicros === null || price.amountMicros === void 0) return t("priceNotListed");
  const perResult = price.unit === "result";
  if (price.amountMicros === 0) return t(perResult ? "freePerResult" : "freePerCall");
  return t(perResult ? "pricePerResult" : "pricePerCall", usd(price.amountMicros / 1e6));
}
function jobFrom(p) {
  if (!p) return t("priceLoading");
  if (p.cheapestPerCall !== null && p.cheapestPerCall > 0) return t("fromPerCall", usd(p.cheapestPerCall));
  if (p.cheapestPerCall === 0 && p.cheapestPerResult !== null && p.cheapestPerResult > 0) return t("freeOneProvider", usd(p.cheapestPerResult));
  if (p.cheapestPerCall === 0) return t("freeCheapest");
  if (p.cheapestPerResult !== null) return t("fromPerResult", usd(p.cheapestPerResult));
  return t("priceNotListed");
}
function parseUsd(text) {
  const n = Number(text.replace(/[$\s]/g, "").replace(",", "."));
  return Number.isFinite(n) && n > 0 ? n : null;
}

// src/lib/read.ts
function squash(k) {
  return k.toLowerCase().replace(/[\s_\-.]/g, "");
}
function scalar(v) {
  if (typeof v === "string") return v.trim();
  if (typeof v === "number" && Number.isFinite(v)) return String(v);
  return "";
}
function findValue(source, keys) {
  const wanted = keys.map(squash);
  let level = [source];
  for (let depth = 0; depth < 5 && level.length > 0; depth++) {
    const next = [];
    for (const node of level) {
      if (node === null || typeof node !== "object") continue;
      if (Array.isArray(node)) {
        next.push(...node.slice(0, 5));
        continue;
      }
      const entries = Object.entries(node);
      for (const key of wanted) {
        for (const [k, v] of entries) {
          if (squash(k) !== key) continue;
          const s = scalar(v);
          if (s) return s;
        }
      }
      for (const [, v] of entries) if (v !== null && typeof v === "object") next.push(v);
    }
    level = next;
  }
  return "";
}
function pick(run, keys) {
  return findValue(run.normalized?.fields ?? null, keys) || findValue(run.result ?? null, keys);
}
var EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
function readEmail(run) {
  const direct = pick(run, ["email", "work_email", "emailAddress"]);
  if (direct && EMAIL_RE.test(direct)) return direct.match(EMAIL_RE)?.[0] ?? "";
  const m = JSON.stringify(run.result ?? "").match(EMAIL_RE);
  return m ? m[0] : "";
}
var STATUS_WORDS = {
  valid: "valid",
  deliverable: "valid",
  ok: "valid",
  safe: "valid",
  verified: "valid",
  invalid: "invalid",
  undeliverable: "invalid",
  bounce: "invalid",
  bad: "invalid",
  catchall: "catch-all",
  acceptall: "catch-all",
  risky: "risky",
  unknown: "unknown"
};
function readStatus(run) {
  const raw = pick(run, ["email_status", "verdict", "result", "status", "check", "state"]);
  return STATUS_WORDS[squash(raw)] ?? (raw ? "unknown" : "");
}
function readCompany(run) {
  const rows = [
    ["fieldName", ["name", "company_name", "companyName", "display_name", "legal_name"]],
    ["fieldIndustry", ["industry", "category", "sector"]],
    ["fieldEmployees", ["employees", "employee_count", "employeeCount", "size", "headcount", "estimated_num_employees"]],
    ["fieldFounded", ["founded", "founded_year", "foundedYear", "year_founded"]],
    ["fieldCountry", ["country", "country_code", "countryCode", "hq_country"]],
    ["fieldCity", ["city", "locality", "hq_city"]],
    ["fieldLinkedIn", ["linkedin_url", "linkedinUrl", "linkedin"]],
    ["fieldAbout", ["description", "short_description", "summary", "tagline"]]
  ];
  return rows.map(([label, keys]) => ({ label, value: pick(run, keys) })).filter((f) => f.value !== "");
}
function findNode(source, keys) {
  const wanted = keys.map(squash);
  let level = [source];
  for (let depth = 0; depth < 5 && level.length > 0; depth++) {
    const next = [];
    for (const node of level) {
      if (node === null || typeof node !== "object") continue;
      if (Array.isArray(node)) {
        next.push(...node.slice(0, 5));
        continue;
      }
      const entries = Object.entries(node);
      for (const key of wanted) {
        for (const [k, v] of entries) if (squash(k) === key && v !== null && v !== void 0 && v !== "") return v;
      }
      for (const [, v] of entries) if (v !== null && typeof v === "object") next.push(v);
    }
    level = next;
  }
  return void 0;
}
function num(v) {
  const n = typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" ? Number(v) : NaN;
  return Number.isFinite(n) ? n : null;
}
function compact(n, locale) {
  return new Intl.NumberFormat(locale, { notation: "compact", maximumFractionDigits: 1 }).format(n);
}
function whole(n, locale) {
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(n);
}
function day(v) {
  const s = typeof v === "string" ? v.trim() : "";
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : "";
}
function readTraffic(run, locale) {
  const src = run.result ?? null;
  const fields = [];
  const add = (label, value) => {
    if (value) fields.push({ label, value });
  };
  let visits = num(findNode(src, ["visits", "monthly_visits", "monthlyVisits"]));
  const series = findNode(src, ["estimatedMonthlyVisits"]);
  if (visits === null && series && typeof series === "object") {
    const last = Object.entries(series).sort(([a], [b]) => a.localeCompare(b)).pop();
    visits = last ? num(last[1]) : null;
  }
  add("fieldVisits", visits === null ? "" : compact(visits, locale));
  const global = num(findNode(findNode(src, ["globalRank", "global_rank"]), ["rank"]) ?? findNode(src, ["globalRank", "global_rank"]));
  add("fieldGlobalRank", global === null ? "" : `#${whole(global, locale)}`);
  const countryNode = findNode(src, ["countryRank", "country_rank"]);
  const countryRank = num(findNode(countryNode, ["rank"]) ?? countryNode);
  const countryCode = findValue(countryNode, ["countryCode", "country_code"]);
  add("fieldCountryRank", countryRank === null ? "" : `#${whole(countryRank, locale)}${countryCode ? ` (${countryCode})` : ""}`);
  add("fieldCategory", findValue(src, ["category"]));
  const bounce = num(findNode(src, ["bounceRate", "bounce_rate"]));
  add("fieldBounce", bounce === null ? "" : `${Math.round(bounce <= 1 ? bounce * 100 : bounce)}%`);
  const ppv = num(findNode(src, ["pagePerVisit", "pages_per_visit", "pagesPerVisit"]));
  add("fieldPagesPerVisit", ppv === null ? "" : ppv.toFixed(1));
  const time = num(findNode(src, ["timeOnSite", "time_on_site", "avgVisitDuration"]));
  add("fieldTimeOnSite", time === null ? "" : `${Math.floor(time / 60)}:${String(Math.round(time % 60)).padStart(2, "0")}`);
  const chips = [];
  const sources = findNode(src, ["trafficSources", "traffic_sources"]);
  if (sources && typeof sources === "object" && !Array.isArray(sources)) {
    const rows = Object.entries(sources).map(([k, v]) => [k, num(v)]).filter((r) => r[1] !== null && r[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 6);
    for (const [k, v] of rows) chips.push(`${k.replace(/([a-z])([A-Z])/g, "$1 $2")} ${Math.round(v <= 1 ? v * 100 : v)}%`);
  }
  return { fields, chips };
}
function readSeo(run, locale) {
  const fields = [];
  const get = (keys) => num(findNode(run.normalized?.fields ?? null, keys) ?? findNode(run.result ?? null, keys));
  const rank = get(["rank", "domain_rank", "domainRank", "domain_rating"]);
  const backlinks = get(["backlinks", "backlinks_count", "total_backlinks"]);
  const refDomains = get(["referringDomains", "referring_domains", "refdomains"]);
  const spam = get(["backlinks_spam_score", "spam_score"]);
  if (rank !== null) fields.push({ label: "fieldDomainRank", value: whole(rank, locale) });
  if (backlinks !== null) fields.push({ label: "fieldBacklinks", value: compact(backlinks, locale) });
  if (refDomains !== null) fields.push({ label: "fieldRefDomains", value: compact(refDomains, locale) });
  if (spam !== null) fields.push({ label: "fieldSpamScore", value: whole(spam, locale) });
  const first = day(findNode(run.result ?? null, ["first_seen", "firstSeen"]));
  if (first) fields.push({ label: "fieldFirstSeen", value: first });
  return { fields, chips: [] };
}
function readWhois(run) {
  const src = run.result ?? null;
  const fields = [];
  const add = (label, value) => {
    if (value) fields.push({ label, value });
  };
  const registrant = findNode(src, ["registrant"]);
  add("fieldOwnerOrg", findValue(registrant, ["organization", "org", "name"]));
  add("fieldOwnerCountry", findValue(registrant, ["country", "countryCode"]));
  add("fieldRegistrar", findValue(src, ["registrarName", "registrar"]));
  add("fieldCreated", day(findNode(src, ["createdDate", "creation_date", "created"])));
  add("fieldExpires", day(findNode(src, ["expiresDate", "expiration_date", "expires"])));
  const ageDays = num(findNode(src, ["estimatedDomainAge"]));
  if (ageDays !== null) add("fieldAgeYears", String(Math.floor(ageDays / 365)));
  let hosts = findNode(src, ["hostNames"]);
  if (!Array.isArray(hosts)) hosts = findNode(src, ["name_servers", "nameservers"]);
  const chips = Array.isArray(hosts) ? hosts.filter((x) => typeof x === "string").slice(0, 6).map((x) => x.toLowerCase()) : [];
  const redacted = /mask|redact|privacy/i.test(findValue(src, ["dataError"])) || !findValue(registrant, ["organization", "org", "name"]);
  return { fields, chips, redacted };
}
var TECH_KEY = /tech|stack|tool|framework|product/i;
var NAME_KEYS = ["name", "technology", "tech", "title", "product", "slug"];
function readTechnologies(run, max = 60) {
  const out = /* @__PURE__ */ new Set();
  const visit = (node, underTech, depth) => {
    if (out.size >= max || depth > 6 || node === null || node === void 0) return;
    if (Array.isArray(node)) {
      for (const item of node) {
        if (out.size >= max) return;
        if (typeof item === "string") {
          if (underTech && item.trim() && item.length <= 60) out.add(item.trim());
        } else if (item && typeof item === "object" && !Array.isArray(item) && underTech) {
          const rec = item;
          const key = NAME_KEYS.find((k) => typeof rec[k] === "string" && rec[k].trim() !== "");
          if (key) out.add(rec[key].trim());
          for (const [k, v] of Object.entries(rec)) if (v && typeof v === "object") visit(v, TECH_KEY.test(k), depth + 1);
        } else {
          visit(item, underTech, depth + 1);
        }
      }
      return;
    }
    if (typeof node === "object") {
      for (const [k, v] of Object.entries(node)) {
        if (v && typeof v === "object") visit(v, underTech || TECH_KEY.test(k), depth + 1);
      }
    }
  };
  visit(run.normalized?.fields ?? null, false, 0);
  visit(run.result ?? null, false, 0);
  return [...out];
}

// src/lib/spend.ts
var EMPTY_SPEND = { spent: 0, reserved: 0, runs: 0 };
var round = (n) => Math.round(n * 1e6) / 1e6;
function canSpend(s, cap, maxCost) {
  return round(s.spent + s.reserved + maxCost) <= round(cap);
}
function left(s, cap) {
  return Math.max(0, round(cap - s.spent - s.reserved));
}
function reserve(s, maxCost) {
  return { ...s, reserved: round(s.reserved + maxCost) };
}
function settle(s, maxCost, actual) {
  return {
    spent: round(s.spent + (actual === null ? maxCost : Math.max(0, actual))),
    reserved: Math.max(0, round(s.reserved - maxCost)),
    runs: s.runs + 1
  };
}

// src/lib/runner.ts
async function runStep(deps, job, input, idempotencyKey) {
  const { maxPerCall, sessionCap } = deps.limits();
  const before = deps.getSpend();
  if (!canSpend(before, sessionCap, maxPerCall)) {
    throw new LoootError(
      0,
      "session_cap",
      `This call can charge up to ${usd(maxPerCall)} and only ${usd(left(before, sessionCap))} is left under your ${usd(sessionCap)} session cap. Raise the cap or reset the counter in Settings.`
    );
  }
  await deps.setSpend(reserve(before, maxPerCall));
  let run;
  try {
    run = await deps.client.runJob(job, input, idempotencyKey, { maxAttempts: 3, maxCostUsd: maxPerCall });
  } catch (err) {
    const refused = err instanceof LoootError && err.status >= 400 && err.status < 500;
    await deps.setSpend(settle(deps.getSpend(), maxPerCall, refused ? 0 : null));
    throw err;
  }
  const settled = TERMINAL.has(run.status);
  const actual = settled ? Math.max(0, run.actualCost ?? 0) : null;
  await deps.setSpend(settle(deps.getSpend(), maxPerCall, actual));
  return { run, counted: actual ?? maxPerCall, settled };
}

// src/lib/store.ts
var DEFAULTS = { token: "", maxPerCall: 0.1, sessionCap: 1 };
var num2 = (v, fallback) => typeof v === "number" && Number.isFinite(v) && v > 0 ? v : fallback;
async function loadSettings(local2) {
  const raw = await local2.get(["token", "maxPerCall", "sessionCap"]);
  return {
    token: typeof raw.token === "string" ? raw.token : "",
    maxPerCall: num2(raw.maxPerCall, DEFAULTS.maxPerCall),
    sessionCap: num2(raw.sessionCap, DEFAULTS.sessionCap)
  };
}
async function saveToken(local2, token) {
  const t2 = token.trim();
  if (t2) await local2.set({ token: t2 });
  else await local2.remove(["token"]);
}
function saveLimits(local2, maxPerCall, sessionCap) {
  return local2.set({ maxPerCall, sessionCap });
}
async function loadSpend(session2) {
  const raw = (await session2.get(["spend"])).spend;
  if (!raw) return { ...EMPTY_SPEND };
  return { spent: Math.round((num2(raw.spent, 0) + num2(raw.reserved, 0)) * 1e6) / 1e6, reserved: 0, runs: num2(raw.runs, 0) };
}
function saveSpend(session2, spend) {
  return session2.set({ spend });
}

// src/panel/dom.ts
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === void 0 || v === false) continue;
    if (k.startsWith("on") && typeof v === "function") {
      el.addEventListener(k.slice(2).toLowerCase(), v);
    } else if (k === "class") {
      el.className = String(v);
    } else if (k === "value" && "value" in el) {
      el.value = String(v);
    } else {
      el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  for (const c of children) if (c !== null && c !== void 0 && c !== false) el.append(c);
  return el;
}
function mount(target, ...children) {
  target.replaceChildren(...children.filter((c) => c !== null && c !== void 0 && c !== false));
}
var SVG_NS = "http://www.w3.org/2000/svg";
function icon(d) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", "0 0 16 16");
  svg.setAttribute("width", "16");
  svg.setAttribute("height", "16");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "1.5");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS(SVG_NS, "path");
  path.setAttribute("d", d);
  svg.append(path);
  return svg;
}
var ICONS = {
  search: "M7 12.5a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11ZM14.5 14.5 11 11",
  globe: "M8 14.5a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM1.5 8h13M8 1.5c2 2.2 2 10.8 0 13M8 1.5c-2 2.2-2 10.8 0 13",
  building: "M3 14.5v-12h7v12M10 6.5h3v8M1.5 14.5h13M5.5 5.5h2M5.5 8.5h2M5.5 11.5h2",
  mail: "M1.5 4h13v8.5h-13zM1.5 4.5 8 9l6.5-4.5",
  layers: "M8 1.5 1.5 5 8 8.5 14.5 5 8 1.5ZM1.5 8 8 11.5 14.5 8M1.5 11 8 14.5 14.5 11",
  check: "M3 8.5 6.5 12 13 4.5",
  copy: "M6 6h7.5v7.5H6zM10 3.5V2.5H2.5V10h1",
  alert: "M8 5.5v3.5M8 11.5v.01M8 1.5l6.5 12h-13L8 1.5Z",
  lock: "M4 7.5h8v6H4zM5.5 7.5v-2a2.5 2.5 0 0 1 5 0v2",
  edit: "M2.5 13.5h3l7.5-7.5-3-3-7.5 7.5v3ZM9 4l3 3",
  id: "M1.5 3.5h13v9h-13zM4 6.5h3M4 9.5h5M10.5 6.5h1.5",
  chart: "M1.5 14.5h13M3.5 11.5v-3M7 11.5V5M10.5 11.5V7.5M14 11.5v-8",
  link: "M6.5 9.5l3-3M5 7.5 3.5 9a2.5 2.5 0 0 0 3.5 3.5L8.5 11M11 8.5 12.5 7A2.5 2.5 0 0 0 9 3.5L7.5 5"
};

// src/panel/main.ts
var local = chrome.storage.local;
var session = chrome.storage.session;
var state = {
  settings: { ...DEFAULTS },
  spend: { ...EMPTY_SPEND },
  prices: null,
  pricesError: false,
  tabDomain: null,
  manualDomain: null,
  editingDomain: false,
  balance: null,
  phases: Object.fromEntries(ACTIONS.map((a) => [a.id, { kind: "idle" }])),
  person: { first: "", last: "" },
  catalog: { q: "", status: "idle", items: [], seq: 0 },
  settingsNote: ""
};
var client = createClient({ getToken: async () => state.settings.token });
var $ = (id) => document.getElementById(id);
var domain = () => state.manualDomain ?? state.tabDomain;
var ACTION_ICONS = { company: ICONS.building, whois: ICONS.id, tech: ICONS.layers, traffic: ICONS.chart, seo: ICONS.link, email: ICONS.mail };
var LOCALE = uiLang();
function renderSite() {
  const d = domain();
  if (state.editingDomain || !d) {
    const input = h("input", {
      id: "domain-input",
      type: "text",
      inputmode: "url",
      autocomplete: "off",
      spellcheck: "false",
      placeholder: t("domainPlaceholder"),
      value: d ?? "",
      "aria-describedby": "domain-help"
    });
    const error = h("p", { class: "field-error", role: "alert", hidden: true }, t("domainError"));
    const submit = (e) => {
      e.preventDefault();
      const next = domainFromInput(input.value);
      if (!next) {
        error.hidden = false;
        input.setAttribute("aria-invalid", "true");
        return;
      }
      state.manualDomain = next;
      state.editingDomain = false;
      resetPhases();
      renderSite();
      renderLookup();
    };
    mount(
      $("site"),
      h(
        "form",
        { class: "site-form", onsubmit: submit },
        h("label", { for: "domain-input" }, t("domainLabel")),
        h("div", { class: "row" }, input, h("button", { class: "btn", type: "submit" }, t("domainUse"))),
        error,
        h(
          "p",
          { id: "domain-help", class: "help" },
          d ? t("domainOverride") : t("domainNone")
        )
      )
    );
    if (state.editingDomain) input.focus();
    return;
  }
  mount(
    $("site"),
    h(
      "div",
      { class: "site-chip" },
      h("span", { class: "site-icon" }, icon(ICONS.globe)),
      h(
        "div",
        { class: "site-text" },
        h("span", { class: "eyebrow" }, state.manualDomain ? t("siteTyped") : t("siteTab")),
        h("span", { class: "domain", title: d }, d)
      ),
      h("button", {
        class: "btn ghost small",
        type: "button",
        "aria-label": t("domainChangeLabel"),
        onclick: () => {
          state.editingDomain = true;
          renderSite();
        }
      }, icon(ICONS.edit), t("domainChange"))
    )
  );
}
async function readTab() {
  let next = null;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    next = domainFromUrl(tab?.url);
  } catch {
    next = null;
  }
  if (next === state.tabDomain) return;
  const changed = next !== domain();
  state.tabDomain = next;
  state.manualDomain = null;
  state.editingDomain = false;
  if (changed) resetPhases();
  renderSite();
  renderLookup();
}
function resetPhases() {
  for (const a of ACTIONS) if (state.phases[a.id].kind !== "running") state.phases[a.id] = { kind: "idle" };
}
function renderLookup() {
  const view = $("view-lookup");
  const children = [];
  if (!state.settings.token) {
    children.push(
      h(
        "div",
        { class: "notice" },
        h("span", { class: "notice-icon" }, icon(ICONS.lock)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, t("needTokenTitle")),
          h("p", { class: "help" }, t("needTokenBody")),
          h(
            "div",
            { class: "row" },
            h("button", { class: "btn", type: "button", onclick: () => selectTab("settings") }, t("addToken")),
            h("a", { class: "btn ghost", href: "https://looot.ai/settings", target: "_blank", rel: "noopener" }, t("getToken"))
          )
        )
      )
    );
  }
  if (state.pricesError) {
    children.push(
      h(
        "div",
        { class: "notice warn", role: "alert" },
        h("span", { class: "notice-icon" }, icon(ICONS.alert)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, t("pricesFailedTitle")),
          h("p", { class: "help" }, t("pricesFailedBody")),
          h("button", { class: "btn ghost", type: "button", onclick: () => void loadPrices(true) }, t("tryAgain"))
        )
      )
    );
  }
  children.push(h("ul", { class: "actions" }, ...ACTIONS.map(renderAction)));
  mount(view, ...children);
}
function priceLine(job) {
  if (!state.prices) return h("span", { class: state.pricesError ? "price muted" : "price skeleton" }, state.pricesError ? t("priceUnavailable") : t("fromPerCall", "$0.0000"));
  return h("span", { class: "price" }, jobFrom(state.prices[job]));
}
function renderAction(action) {
  const phase = state.phases[action.id];
  const d = domain();
  const listed = state.prices?.[action.jobs[0]]?.cheapestPerCall ?? null;
  const overCap = listed !== null && listed > state.settings.maxPerCall;
  const ready = Boolean(state.settings.token && state.prices && d && !overCap);
  const head = h(
    "div",
    { class: "action-head" },
    h("span", { class: "action-icon" }, icon(ACTION_ICONS[action.id])),
    h(
      "div",
      { class: "action-text" },
      h("h2", {}, t(`${action.key}Title`)),
      h("p", { class: "help" }, t(`${action.key}Hint`)),
      h("p", { class: "price-row" }, priceLine(action.jobs[0]))
    )
  );
  const body = [];
  if (phase.kind === "idle") {
    if (action.id === "email") {
      const first = h("input", { id: "first-name", type: "text", autocomplete: "off", value: state.person.first, oninput: (e) => {
        state.person.first = e.target.value;
      } });
      const last = h("input", { id: "last-name", type: "text", autocomplete: "off", value: state.person.last, oninput: (e) => {
        state.person.last = e.target.value;
      } });
      const error = h("p", { class: "field-error", role: "alert", hidden: true }, t("nameError"));
      body.push(
        h(
          "form",
          {
            class: "stack",
            onsubmit: (e) => {
              e.preventDefault();
              const f = state.person.first.trim();
              const l = state.person.last.trim();
              if (!f || !l) {
                error.hidden = false;
                return;
              }
              startConfirm(action, { first: f, last: l });
            }
          },
          h(
            "div",
            { class: "grid2" },
            h("div", { class: "field" }, h("label", { for: "first-name" }, t("firstName")), first),
            h("div", { class: "field" }, h("label", { for: "last-name" }, t("lastName")), last)
          ),
          error,
          h("button", { class: "btn", type: "submit", disabled: !ready }, t("seePrice"))
        )
      );
    } else {
      body.push(h("button", { class: "btn", type: "button", disabled: !ready, onclick: () => startConfirm(action, {}) }, t("seePrice")));
    }
    if (!d) body.push(h("p", { class: "help" }, t("needsDomain")));
    if (overCap) {
      body.push(h(
        "p",
        { class: "help warn-text" },
        t("overCap", usd(listed), usd(state.settings.maxPerCall)),
        " ",
        h("button", { class: "linkish", type: "button", onclick: () => selectTab("settings") }, t("openSettings"))
      ));
    }
  }
  if (phase.kind === "confirm") {
    const cap = state.settings.maxPerCall;
    const jobs = action.jobs;
    const most = cap * jobs.length;
    body.push(
      h(
        "div",
        { class: "confirm", role: "group", "aria-label": t("confirmLabel", t(`${action.key}Title`)) },
        h(
          "p",
          { class: "confirm-target" },
          action.id === "email" ? t("confirmPerson", `${phase.first} ${phase.last}`) : t("confirmOn"),
          " ",
          h("span", { class: "domain" }, phase.domain)
        ),
        h(
          "ul",
          { class: "steps" },
          ...jobs.map(
            (job, i) => h(
              "li",
              {},
              h("span", { class: "mono job" }, `job:${job}`),
              h("span", { class: "price" }, jobFrom(state.prices?.[job])),
              i > 0 ? h("span", { class: "help" }, t("verifyOnlyIfFound")) : null
            )
          )
        ),
        h(
          "p",
          { class: "cap-line" },
          t("mostCharge"),
          " ",
          h("strong", { class: "mono" }, usd(most)),
          " ",
          jobs.length > 1 ? t("capEachCall", usd(cap)) : t("capYourCall"),
          " ",
          t("failedFree")
        ),
        h(
          "div",
          { class: "row" },
          h("button", { class: "btn primary", type: "button", onclick: () => void runAction(action, phase) }, t("confirmRun")),
          h("button", { class: "btn ghost", type: "button", onclick: () => setPhase(action.id, { kind: "idle" }) }, t("cancel"))
        )
      )
    );
  }
  if (phase.kind === "running") {
    body.push(
      h(
        "div",
        { class: "running", role: "status" },
        h("span", { class: "spinner", "aria-hidden": "true" }),
        h("span", {}, phase.label)
      ),
      h("div", { class: "skeleton-block", "aria-hidden": "true" }, h("span", {}), h("span", {}), h("span", {}))
    );
  }
  if (phase.kind === "done") {
    const total = phase.steps.reduce((sum, s) => sum + s.counted, 0);
    const raw = JSON.stringify(phase.steps.map((s) => ({ runId: s.run.runId, status: s.run.status, actualCost: s.run.actualCost, result: s.run.result })), null, 2);
    const copy = h("button", { class: "btn ghost small", type: "button", onclick: () => void copyText(raw, copy) }, icon(ICONS.copy), t("copyJson"));
    body.push(
      h(
        "div",
        { class: "result" },
        phase.headline ? h("p", { class: "headline" }, phase.headline) : null,
        phase.note ? h("p", { class: "help" }, phase.note) : null,
        phase.fields.length > 0 ? h("dl", { class: "fields" }, ...phase.fields.flatMap((f) => [h("dt", {}, t(f.label)), h("dd", { title: f.value }, f.value)])) : null,
        phase.chips.length > 0 ? h("ul", { class: "chips" }, ...phase.chips.map((c) => h("li", {}, c))) : null,
        h(
          "div",
          { class: "receipt" },
          h("span", { class: "receipt-label" }, t("charged")),
          h("strong", { class: "mono" }, usd(total)),
          h("span", { class: "help" }, phase.steps.map((s) => s.run.route?.servedBy).filter(Boolean).join(", "))
        ),
        ...phase.steps.filter((s) => !s.settled).map(
          () => h("p", { class: "help" }, t("notSettled"))
        ),
        h("details", {}, h("summary", {}, t("rawAnswer")), h("pre", {}, raw.length > 6e3 ? raw.slice(0, 6e3) + "\n..." : raw)),
        h(
          "div",
          { class: "row" },
          copy,
          h("button", { class: "btn ghost small", type: "button", onclick: () => setPhase(action.id, { kind: "idle" }) }, t("runAnother"))
        )
      )
    );
  }
  if (phase.kind === "error") {
    body.push(
      h(
        "div",
        { class: "notice warn", role: "alert" },
        h("span", { class: "notice-icon" }, icon(ICONS.alert)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, t("nothingRan")),
          h("p", { class: "help" }, phase.message),
          h(
            "div",
            { class: "row" },
            phase.retry ? h("button", { class: "btn", type: "button", onclick: () => setPhase(action.id, phase.retry) }, t("back")) : null,
            phase.topUpUrl ? h("a", { class: "btn ghost", href: phase.topUpUrl, target: "_blank", rel: "noopener" }, t("topUp")) : null,
            h("button", { class: "btn ghost", type: "button", onclick: () => setPhase(action.id, { kind: "idle" }) }, t("dismiss"))
          )
        )
      )
    );
  }
  return h("li", { class: `action is-${phase.kind}`, id: `action-${action.id}` }, head, ...body);
}
function setPhase(id, phase) {
  state.phases[id] = phase;
  renderLookup();
}
function startConfirm(action, person) {
  const d = domain();
  if (!d) return;
  const keys = {};
  for (const job of action.jobs) keys[job] = newKey(job);
  setPhase(action.id, { kind: "confirm", domain: d, keys, ...person });
}
function safeUrl(u) {
  return u && /^https:\/\/([a-z0-9-]+\.)*looot\.ai(\/|$)/.test(u) ? u : void 0;
}
function describeFailure(run) {
  return run.error?.message ?? t("runEnded", run.status);
}
async function runAction(action, phase) {
  const deps = {
    client,
    limits: () => ({ maxPerCall: state.settings.maxPerCall, sessionCap: state.settings.sessionCap }),
    getSpend: () => state.spend,
    setSpend: async (s) => {
      state.spend = s;
      renderMeter();
      await saveSpend(session, s);
    }
  };
  const steps = [];
  const done = (fields, chips, headline, note) => setPhase(action.id, { kind: "done", domain: phase.domain, steps, fields, chips, headline, note });
  const one = async (job, label) => {
    setPhase(action.id, { kind: "running", label });
    const step = await runStep(deps, job, { domain: phase.domain }, phase.keys[job]);
    steps.push(step);
    return step.run.status === "completed" ? step.run : null;
  };
  const failed = () => describeFailure(steps[steps.length - 1].run);
  try {
    if (action.id === "company") {
      const run = await one(JOB_COMPANY, t("runningCompany", phase.domain));
      const fields = run ? readCompany(run) : [];
      const name = fields.find((f) => f.label === "fieldName")?.value ?? "";
      done(fields.filter((f) => f.label !== "fieldName"), [], name, !run ? failed() : fields.length === 0 ? t("emptyCompany") : "");
    } else if (action.id === "whois") {
      const run = await one(JOB_WHOIS, t("runningWhois", phase.domain));
      const card = run ? readWhois(run) : { fields: [], chips: [], redacted: false };
      done(card.fields, card.chips, "", !run ? failed() : card.fields.length === 0 ? t("emptyAnswer") : card.redacted ? t("whoisRedacted") : "");
    } else if (action.id === "tech") {
      const run = await one(JOB_TECH, t("runningTech", phase.domain));
      const names = run ? readTechnologies(run) : [];
      done([], names, names.length > 0 ? t("techCount", names.length) : "", !run ? failed() : names.length === 0 ? t("emptyTech") : "");
    } else if (action.id === "traffic") {
      const run = await one(JOB_TRAFFIC, t("runningTraffic", phase.domain));
      const card = run ? readTraffic(run, LOCALE) : { fields: [], chips: [] };
      done(card.fields, card.chips, "", !run ? failed() : card.fields.length === 0 ? t("emptyAnswer") : t("trafficNote"));
    } else if (action.id === "seo") {
      const run = await one(JOB_SEO, t("runningSeo", phase.domain));
      const card = run ? readSeo(run, LOCALE) : { fields: [], chips: [] };
      done(card.fields, [], "", !run ? failed() : card.fields.length === 0 ? t("emptyAnswer") : "");
    } else {
      setPhase(action.id, { kind: "running", label: t("runningEmail") });
      const find = await runStep(deps, JOB_EMAIL_FIND, { first_name: phase.first ?? "", last_name: phase.last ?? "", domain: phase.domain }, phase.keys[JOB_EMAIL_FIND]);
      steps.push(find);
      const email = find.run.status === "completed" ? readEmail(find.run) : "";
      if (!email) {
        done([], [], "", find.run.status !== "completed" ? describeFailure(find.run) : t("emptyEmail"));
        return;
      }
      setPhase(action.id, { kind: "running", label: t("runningVerify", email) });
      let status = "";
      let note = "";
      try {
        const verify = await runStep(deps, JOB_EMAIL_VERIFY, { email }, phase.keys[JOB_EMAIL_VERIFY]);
        steps.push(verify);
        status = verify.run.status === "completed" ? readStatus(verify.run) : "";
        if (verify.run.status !== "completed") note = t("verifyUnfinished", describeFailure(verify.run));
      } catch (err) {
        note = t("verifyNotRun", err instanceof Error ? err.message : "unknown error");
      }
      const fields = status ? [{ label: "fieldCheck", value: t(`status_${status.replace("-", "")}`) }] : [];
      done(fields, [], email, note);
    }
  } catch (err) {
    const e = err instanceof LoootError ? err : new LoootError(0, "unknown", t("errUnknown"));
    const { maxPerCall, sessionCap } = state.settings;
    const message = e.code === "session_cap" ? t("errSessionCap", usd(maxPerCall), usd(left(state.spend, sessionCap)), usd(sessionCap)) : e.code === "network" ? t("errNetwork") : e.code === "missing_token" ? t("errMissingToken") : e.status === 401 ? t("errToken") : e.status === 402 || e.code.includes("insufficient") ? `${e.message} ${t("errTopUp")}` : e.message;
    if (steps.length > 0) {
      done([], [], "", message);
    } else {
      setPhase(action.id, { kind: "error", message, topUpUrl: safeUrl(e.topUpUrl), retry: e.code === "session_cap" ? void 0 : phase });
    }
  } finally {
    void loadBalance();
  }
}
async function copyText(text, button) {
  try {
    await navigator.clipboard.writeText(text);
    button.classList.add("copied");
    setTimeout(() => button.classList.remove("copied"), 1200);
  } catch {
  }
}
var SUGGESTIONS = ["suggest1", "suggest2", "suggest3", "suggest4", "suggest5", "suggest6"];
function renderCatalog() {
  const view = $("view-catalog");
  const input = h("input", {
    id: "catalog-q",
    type: "search",
    placeholder: t("catalogPlaceholder"),
    autocomplete: "off",
    value: state.catalog.q,
    "aria-label": t("catalogLabel"),
    oninput: (e) => queueSearch(e.target.value)
  });
  mount(
    view,
    h("div", { class: "search" }, h("span", { class: "search-icon" }, icon(ICONS.search)), input),
    h("p", { class: "help" }, t("catalogHelp")),
    h("div", { id: "catalog-results", "aria-live": "polite" })
  );
  renderCatalogResults();
}
function renderCatalogResults() {
  const box = document.getElementById("catalog-results");
  if (!box) return;
  const c = state.catalog;
  if (c.status === "idle") {
    mount(
      box,
      h(
        "div",
        { class: "empty" },
        h("p", { class: "empty-title" }, t("catalogEmptyTitle")),
        h("p", { class: "help" }, t("catalogEmptyBody")),
        h("ul", { class: "chips click" }, ...SUGGESTIONS.map((key) => {
          const s = t(key);
          return h("li", {}, h("button", { type: "button", onclick: () => {
            state.catalog.q = s;
            renderCatalog();
            void search(s);
          } }, s));
        }))
      )
    );
  } else if (c.status === "loading") {
    mount(box, h("ul", { class: "results", "aria-busy": "true" }, ...[0, 1, 2, 3].map(() => h("li", { class: "result-row skeleton-row", "aria-hidden": "true" }, h("span", {}), h("span", {}), h("span", {})))));
  } else if (c.status === "error") {
    mount(
      box,
      h(
        "div",
        { class: "notice warn", role: "alert" },
        h("span", { class: "notice-icon" }, icon(ICONS.alert)),
        h(
          "div",
          {},
          h("p", { class: "notice-title" }, t("searchFailedTitle")),
          h("p", { class: "help" }, t("errNetwork")),
          h("button", { class: "btn ghost", type: "button", onclick: () => void search(c.q) }, t("tryAgain"))
        )
      )
    );
  } else if (c.items.length === 0) {
    mount(
      box,
      h(
        "div",
        { class: "empty" },
        h("p", { class: "empty-title" }, t("noMatchTitle", c.q)),
        h("p", { class: "help" }, t("noMatchBody"))
      )
    );
  } else {
    mount(box, h("ul", { class: "results" }, ...c.items.map(renderItem)));
  }
}
function plain(text) {
  return text.replace(/\*\*|`/g, "").replace(/\s+/g, " ").trim();
}
function renderItem(item) {
  const slash = item.title.indexOf(" / ");
  const provider = slash > 0 ? item.title.slice(0, slash) : item.providerId;
  const title = slash > 0 ? item.title.slice(slash + 3) : item.title;
  const copy = h("button", { class: "btn ghost small", type: "button", title: t("copyIdTitle"), onclick: () => void copyText(item.operationId, copy) }, icon(ICONS.copy), t("copyId"));
  return h(
    "li",
    { class: "result-row" },
    h(
      "div",
      { class: "result-top" },
      h("span", { class: "eyebrow" }, provider),
      h("span", { class: "price" }, itemPrice(item.price))
    ),
    h("h3", {}, title),
    item.description ? h("p", { class: "help clamp" }, plain(item.description)) : null,
    h("div", { class: "result-foot" }, h("code", { class: "mono id", title: item.operationId }, item.operationId), copy)
  );
}
var searchTimer;
function queueSearch(q) {
  state.catalog.q = q;
  clearTimeout(searchTimer);
  if (!q.trim()) {
    state.catalog.status = "idle";
    state.catalog.seq++;
    renderCatalogResults();
    return;
  }
  searchTimer = setTimeout(() => void search(q), 300);
}
async function search(q) {
  const text = q.trim().slice(0, 200);
  if (!text) return;
  const seq = ++state.catalog.seq;
  state.catalog.status = "loading";
  renderCatalogResults();
  try {
    const items = await client.searchCatalog(text, 20);
    if (seq !== state.catalog.seq) return;
    state.catalog.items = items;
    state.catalog.status = "done";
  } catch {
    if (seq !== state.catalog.seq) return;
    state.catalog.status = "error";
  }
  renderCatalogResults();
}
function renderSettings() {
  const view = $("view-settings");
  const hasToken = Boolean(state.settings.token);
  const token = h("input", { id: "token", type: "password", autocomplete: "off", spellcheck: "false", placeholder: hasToken ? t("tokenSavedPlaceholder") : "cs_ms_..." });
  const tokenNote = h("p", { class: "help", role: "status" }, state.settingsNote);
  const perCall = h("input", { id: "max-per-call", type: "text", inputmode: "decimal", value: String(state.settings.maxPerCall) });
  const cap = h("input", { id: "session-cap", type: "text", inputmode: "decimal", value: String(state.settings.sessionCap) });
  const limitsError = h("p", { class: "field-error", role: "alert", hidden: true }, t("limitsError"));
  const limitsNote = h("p", { class: "help", role: "status" });
  mount(
    view,
    h(
      "form",
      {
        class: "stack card",
        onsubmit: (e) => {
          e.preventDefault();
          const value = token.value.trim();
          if (!value) return;
          void (async () => {
            await saveToken(local, value);
            state.settings.token = value;
            state.settingsNote = t("tokenSaved");
            try {
              const b = await client.balance();
              state.balance = typeof b?.available === "number" ? b.available : null;
            } catch (err) {
              state.balance = null;
              if (err instanceof LoootError && err.status === 401) state.settingsNote = t("tokenRejected");
            }
            renderAll();
          })();
        }
      },
      h("h2", {}, t("tokenTitle")),
      h(
        "div",
        { class: "field" },
        h("label", { for: "token" }, t("tokenLabel")),
        token,
        h("p", { class: "help" }, t("tokenHelp"))
      ),
      tokenNote,
      h(
        "div",
        { class: "row" },
        h("button", { class: "btn primary", type: "submit" }, hasToken ? t("tokenReplace") : t("tokenSave")),
        hasToken ? h("button", {
          class: "btn ghost",
          type: "button",
          onclick: () => void (async () => {
            await saveToken(local, "");
            state.settings.token = "";
            state.balance = null;
            state.settingsNote = t("tokenRemoved");
            renderAll();
          })()
        }, t("tokenRemove")) : null
      ),
      h(
        "p",
        { class: "help" },
        t("tokenHowBefore"),
        " ",
        h("a", { href: "https://looot.ai/settings", target: "_blank", rel: "noopener" }, t("tokenHowLink")),
        " ",
        t("tokenHowAfter")
      )
    ),
    h(
      "form",
      {
        class: "stack card",
        onsubmit: (e) => {
          e.preventDefault();
          const a = parseUsd(perCall.value);
          const b = parseUsd(cap.value);
          if (a === null || b === null || b < a) {
            limitsError.hidden = false;
            return;
          }
          limitsError.hidden = true;
          state.settings.maxPerCall = a;
          state.settings.sessionCap = b;
          void saveLimits(local, a, b).then(() => {
            limitsNote.textContent = t("limitsSaved");
            renderMeter();
            renderLookup();
          });
        }
      },
      h("h2", {}, t("limitsTitle")),
      h(
        "div",
        { class: "grid2" },
        h("div", { class: "field" }, h("label", { for: "max-per-call" }, t("capPerCall")), perCall),
        h("div", { class: "field" }, h("label", { for: "session-cap" }, t("capSession")), cap)
      ),
      limitsError,
      h("p", { class: "help" }, t("limitsHelp")),
      limitsNote,
      h(
        "div",
        { class: "row" },
        h("button", { class: "btn", type: "submit" }, t("limitsSave")),
        h("button", {
          class: "btn ghost",
          type: "button",
          onclick: () => {
            state.spend = { ...EMPTY_SPEND };
            void saveSpend(session, state.spend);
            renderMeter();
            limitsNote.textContent = t("counterReset");
          }
        }, t("counterResetButton"))
      )
    ),
    h(
      "div",
      { class: "card links" },
      h("h2", {}, t("aboutTitle")),
      h("p", { class: "help" }, t("aboutBody")),
      h(
        "p",
        { class: "link-row" },
        h("a", { href: "https://looot.ai", target: "_blank", rel: "noopener" }, "looot.ai"),
        h("a", { href: "https://docs.looot.ai", target: "_blank", rel: "noopener" }, t("linkDocs")),
        h("a", { href: "https://looot.ai/privacy", target: "_blank", rel: "noopener" }, t("linkPrivacy")),
        h("a", { href: "https://looot.ai/contact", target: "_blank", rel: "noopener" }, t("linkSupport")),
        h("a", { href: "https://github.com/loootai/looot-chrome", target: "_blank", rel: "noopener" }, t("linkSource"))
      )
    )
  );
}
function renderMeter() {
  const { spend, settings } = state;
  const used = spend.spent + spend.reserved;
  const pct = Math.min(100, Math.round(used / settings.sessionCap * 100));
  mount(
    $("meter"),
    h(
      "div",
      { class: "meter-row" },
      h("span", {}, t("meterSession"), " ", h("strong", { class: "mono" }, usd(spend.spent)), " ", t("meterOf", usd(settings.sessionCap))),
      h("span", { class: "help" }, spend.reserved > 0 ? t("meterHeld", usd(spend.reserved)) : t(spend.runs === 1 ? "meterLeftOne" : "meterLeft", usd(left(spend, settings.sessionCap)), spend.runs))
    ),
    h(
      "div",
      { class: `bar${pct >= 90 ? " full" : ""}`, role: "progressbar", "aria-label": t("meterLabel"), "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": pct },
      h("span", { style: `transform: scaleX(${pct / 100})` })
    )
  );
}
function renderBalance() {
  const el = $("balance");
  if (state.balance === null || !state.settings.token) {
    el.hidden = true;
    return;
  }
  el.hidden = false;
  mount(el, h("span", { class: "eyebrow" }, t("balance")), h("strong", { class: "mono" }, usd(Math.round(state.balance * 100) / 100)));
}
async function loadBalance() {
  if (!state.settings.token) return;
  try {
    const b = await client.balance();
    state.balance = typeof b?.available === "number" ? b.available : null;
  } catch {
    state.balance = null;
  }
  renderBalance();
}
async function loadPrices(force = false) {
  state.pricesError = false;
  if (force) {
    state.prices = null;
    renderLookup();
  }
  try {
    const cached = (await session.get(["prices"])).prices;
    if (!force && cached && Date.now() - cached.at < 30 * 6e4) {
      state.prices = cached.jobs;
    } else {
      state.prices = await client.jobPrices(ALL_JOBS);
      await session.set({ prices: { at: Date.now(), jobs: state.prices } });
    }
  } catch {
    state.prices = null;
    state.pricesError = true;
  }
  renderLookup();
}
function selectTab(name) {
  for (const tab of document.querySelectorAll('[role="tab"]')) {
    const on = tab.dataset.tab === name;
    tab.setAttribute("aria-selected", String(on));
    tab.tabIndex = on ? 0 : -1;
    $(`view-${tab.dataset.tab}`).hidden = !on;
  }
  if (name === "settings") {
    state.settingsNote = "";
    renderSettings();
  }
}
function translateStatic() {
  document.documentElement.lang = LOCALE ?? "en";
  for (const el of document.querySelectorAll("[data-i18n]")) el.textContent = t(el.dataset.i18n ?? "");
  for (const el of document.querySelectorAll("[data-i18n-label]")) el.setAttribute("aria-label", t(el.dataset.i18nLabel ?? ""));
}
function renderAll() {
  renderSite();
  renderLookup();
  renderSettings();
  renderMeter();
  renderBalance();
}
async function init() {
  translateStatic();
  const tabs = [...document.querySelectorAll('[role="tab"]')];
  tabs.forEach((tab, i) => {
    tab.addEventListener("click", () => selectTab(tab.dataset.tab ?? "lookup"));
    tab.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const next = tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
      next.focus();
      selectTab(next.dataset.tab ?? "lookup");
    });
  });
  state.settings = await loadSettings(local);
  state.spend = await loadSpend(session);
  renderAll();
  renderCatalog();
  await readTab();
  chrome.tabs.onActivated.addListener(() => void readTab());
  chrome.tabs.onUpdated.addListener((_id, info) => {
    if (info.url || info.status === "complete") void readTab();
  });
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "looot:tab-granted") void readTab();
  });
  void loadPrices();
  void loadBalance();
}
void init();
