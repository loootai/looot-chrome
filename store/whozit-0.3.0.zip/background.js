// src/background.ts
chrome.action.onClicked.addListener((tab) => {
  if (tab.windowId === void 0) return;
  void chrome.sidePanel.open({ windowId: tab.windowId }).then(() => {
    chrome.runtime.sendMessage({ type: "looot:tab-granted" }).catch(() => void 0);
  });
});
